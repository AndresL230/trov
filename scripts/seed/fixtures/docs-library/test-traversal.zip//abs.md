# Absolute

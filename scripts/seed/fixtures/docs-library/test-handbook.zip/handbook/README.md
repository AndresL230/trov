# Engineering handbook

Welcome. Start with [Local setup](onboarding/local-setup.md), read [the glossary](glossary.md) and [a file that is not here](nowhere/missing.md).

![The deploy flow](attachments/flow.png)

Inline code is left alone: `[[not-a-link]]`.

# Code sample

```js
const x = "[[not-a-link-either]]";
```

Back to [the handbook](README.md).

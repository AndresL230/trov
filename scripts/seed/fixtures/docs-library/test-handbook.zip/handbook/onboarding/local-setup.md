# Local setup

Install Node 20 and pnpm 9.

Run pnpm setup to create your local database.

# Your first week

Day one: [accounts](accounts.md). Then [Deploys](../operations/deploys.md).

# Rolling back a bad deploy

Revert, then redeploy. See [Deploys](../deploys.md).
